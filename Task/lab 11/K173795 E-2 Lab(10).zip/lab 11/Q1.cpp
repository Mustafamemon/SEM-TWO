#include<iostream>
#include<fstream>
#include<stdio.h>
using namespace std ;
int main()
{
	string name;
	char n;
	cout<<"Enter the string: ";
	cin>>name;
	fstream f ;
	f.open("Myfile.txt",ios::out|ios::app);
	for(int i=0;i<=name.length();i++)
	{
		f.put(name[i]);
		
	}
	f.close();
	f.open("Myfile.txt",ios::in);
	while(!f.eof())
	{
		f.get(n);
		cout<<n;
	}
	f.close();
}
