#include<iostream>
using namespace std;
template<typename T>
class bubble{
private:
	int size;
	T *ptr;
public:
	bubble(int s=10)
	{
		size=s;
		ptr=new T[size];
		cout<<"\nEnter The Element Of the Array : ";
		for(int i=0;i<size;i++)
		cin>>ptr[i];
	}
	void func()
	{
		T temp;
		for (int i=0;i<size;i++)
		{
			for(int j=i+1;j<size;j++)
			{
				if(ptr[i]>ptr[j])
				{
					temp=ptr[i];
					ptr[i]=ptr[j];
					ptr[j]=temp;
				}
			}
		}
	}
	void display()
	{
		for (int i=0;i<size;i++)
		cout<<ptr[i]<<"\t";
	}
	~bubble()
	{
		delete []ptr;
	}
};
int main()
{
	bubble<int> obj(5);
	cout<<"\n\nBEFORE SORTING\n";
	obj.display();
	obj.func();
	cout<<"\n\nAFTER SORTING\n";
	obj.display();
	bubble<float> obj1(5);
	cout<<"\n\nBEFORE SORTING\n";
	obj1.display();
	obj1.func();
	cout<<"\n\nAFTER SORTING\n";
	obj1.display();
}
