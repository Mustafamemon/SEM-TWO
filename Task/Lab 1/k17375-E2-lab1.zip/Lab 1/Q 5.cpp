#include <iostream> //headerfile
using namespace std; 
int main() 
{
	int  x , y , z , result ; // declartion of variable
	cout<<"enter three integers : " ; //prompt user to enter number 
	cin>>x>>y>>z ; //input
	result = x*y*z ; //multiplication
	cout<<"The product is : "<<result<<endl ; //final result
}
