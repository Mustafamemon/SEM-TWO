#include<iostream>
using namespace std ;
class student{
	string name ;
	int roll ;
	int sems ;
	char sec ;
public :
	student(string name , int roll , int sems , char sec ){
		this->name = name ;
		this->roll = roll ;
		this->sec = sec ;
		this->sems = sems ;
	}
	void get_data(){
		cout<<"NAME : "<<name<<endl<<"ROLL NO : "<<roll<<endl<<"SECTION : "<<sec<<endl<<"SEMESTER : "<<sems ;
	}
};
int main(){
	student s("MUSTAFA",173795,2,'E');
	s.get_data();
}
